#include "Undistort.h"

Vec2d Undistortpoint(Vec2d imp)
{
	Mat_<float> cam(3,3); cam << 7.6836811279556614e+03, 0., 2.9995, 0., 7.6836811279556614e+03, 1.9995, 0., 0., 1;
	Mat_<float> dist(1,5); dist <<-2.3144078493029768e-01, 3.2336005130116710e+00, 0., 0., -3.5098482178351105e+01;

	const int npoints = 4; // number of point specified

	// Points initialization.
	// Only 2 ponts in this example, in real code they are read from file.

	Mat_<Point2d> points(1,npoints);
	points(0) = Point2f(imp[0],imp[1]);
	points(1) = Point2f(500, 300);
	points(2) = Point2f(2000, 3000);
	points(3) = Point2f(1504, 3024);

	Mat dst;
	undistortPoints(points, dst, cam, dist,cv::noArray(),cam);
	MatIterator_<double> i;

	Vec2d cp = dst.at<double>(0,0);
	cp[0] = dst.at<double>(0);
	cp[1] = dst.at<double>(1);

	return cp;
}
