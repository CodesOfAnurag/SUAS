#include <iostream>
#include <sstream>
#include <string>
#include <ctime>
#include <cstdio>

#include <opencv2/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>

#define fx 7.6836811279556614e+03;
#define fy 7.6836811279556614e+03;
#define cx 2.9995;
#define cy 1.9995;

using namespace cv;
using namespace std;


namespace Edhitha2016 {
	Vec2d Undistortpoint(Vec2d imp);
}

